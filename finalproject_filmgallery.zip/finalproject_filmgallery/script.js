$(function() {
	$( ".draggable" ).draggable();
});

console.log("hello")